package com.iristechnology.maslak;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;


@SpringBootApplication
public class MaslakApplication {

	public static void main(String[] args) {

		SpringApplication.run(MaslakApplication.class, args);
	}




}
