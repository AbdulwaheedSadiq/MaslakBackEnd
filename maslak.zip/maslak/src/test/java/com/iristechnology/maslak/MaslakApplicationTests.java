package com.iristechnology.maslak;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaslakApplicationTests {

	@Test
	void contextLoads() {
	}

}
